package com.example.travelbooking;

import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

public class MainActivity extends AppCompatActivity {

    // UI Components
    private EditText etName, etEmail, etPhone, etAge;
    private Spinner spinnerDestination;
    private RadioGroup rgClass;
    private RadioButton rbEconomy, rbBusiness, rbFirst;
    private CheckBox cbBaggage, cbMeal, cbInsurance;
    private ImageView ivBanner;
    private Button btnBook, btnHistory, btnSocial;

    private SharedPreferences sharedPreferences;
    private static final String PREF_NAME = "TravelBookingPref";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Setup Toolbar
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        sharedPreferences = getSharedPreferences(PREF_NAME, MODE_PRIVATE);

        initViews();
        setupSpinner();
        loadSavedData();
    }

    private void initViews() {
        etName        = findViewById(R.id.et_name);
        etEmail       = findViewById(R.id.et_email);
        etPhone       = findViewById(R.id.et_phone);
        etAge         = findViewById(R.id.et_age);
        spinnerDestination = findViewById(R.id.spinner_destination);
        rgClass       = findViewById(R.id.rg_class);
        rbEconomy     = findViewById(R.id.rb_economy);
        rbBusiness    = findViewById(R.id.rb_business);
        rbFirst       = findViewById(R.id.rb_first);
        cbBaggage     = findViewById(R.id.cb_baggage);
        cbMeal        = findViewById(R.id.cb_meal);
        cbInsurance   = findViewById(R.id.cb_insurance);
        ivBanner      = findViewById(R.id.iv_banner);
        btnBook       = findViewById(R.id.btn_book);
        btnHistory    = findViewById(R.id.btn_history);
        btnSocial     = findViewById(R.id.btn_social);

        btnBook.setOnClickListener(v -> validateAndBook());
        btnHistory.setOnClickListener(v -> openHistory());
        btnSocial.setOnClickListener(v -> openSocialMedia());
    }

    private void setupSpinner() {
        String[] destinations = {
            "-- Pilih Destinasi --",
            "Bali, Indonesia",
            "Yogyakarta, Indonesia",
            "Lombok, Indonesia",
            "Raja Ampat, Papua",
            "Labuan Bajo, NTT",
            "Bangka Belitung",
            "Manado, Sulawesi"
        };
        ArrayAdapter<String> adapter = new ArrayAdapter<>(
            this, android.R.layout.simple_spinner_item, destinations);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerDestination.setAdapter(adapter);
    }

    private void loadSavedData() {
        etName.setText(sharedPreferences.getString("last_name", ""));
        etEmail.setText(sharedPreferences.getString("last_email", ""));
        etPhone.setText(sharedPreferences.getString("last_phone", ""));
    }

    private void validateAndBook() {
        String name  = etName.getText().toString().trim();
        String email = etEmail.getText().toString().trim();
        String phone = etPhone.getText().toString().trim();
        String age   = etAge.getText().toString().trim();

        // Validasi: tidak boleh kosong
        if (name.isEmpty()) {
            etName.setError("Nama tidak boleh kosong");
            etName.requestFocus();
            return;
        }
        if (email.isEmpty()) {
            etEmail.setError("Email tidak boleh kosong");
            etEmail.requestFocus();
            return;
        }
        // Validasi: email harus mengandung @
        if (!email.contains("@")) {
            etEmail.setError("Email harus mengandung '@'");
            etEmail.requestFocus();
            return;
        }
        if (phone.isEmpty()) {
            etPhone.setError("Nomor HP tidak boleh kosong");
            etPhone.requestFocus();
            return;
        }
        // Validasi: phone harus angka
        if (!phone.matches("[0-9]+")) {
            etPhone.setError("Nomor HP hanya boleh angka");
            etPhone.requestFocus();
            return;
        }
        if (age.isEmpty()) {
            etAge.setError("Usia tidak boleh kosong");
            etAge.requestFocus();
            return;
        }
        // Validasi: usia harus angka
        if (!age.matches("[0-9]+")) {
            etAge.setError("Usia harus berupa angka");
            etAge.requestFocus();
            return;
        }
        int ageInt = Integer.parseInt(age);
        if (ageInt < 1 || ageInt > 120) {
            etAge.setError("Usia tidak valid (1-120)");
            etAge.requestFocus();
            return;
        }
        // Validasi: destinasi harus dipilih
        if (spinnerDestination.getSelectedItemPosition() == 0) {
            Toast.makeText(this, "Pilih destinasi terlebih dahulu", Toast.LENGTH_SHORT).show();
            return;
        }
        // Validasi: kelas harus dipilih
        if (rgClass.getCheckedRadioButtonId() == -1) {
            Toast.makeText(this, "Pilih kelas penerbangan", Toast.LENGTH_SHORT).show();
            return;
        }

        // Simpan ke SharedPreferences
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putString("last_name",  name);
        editor.putString("last_email", email);
        editor.putString("last_phone", phone);
        editor.apply();

        // Kumpulkan data extras
        String destination = spinnerDestination.getSelectedItem().toString();
        String flightClass = ((RadioButton) findViewById(rgClass.getCheckedRadioButtonId()))
                                .getText().toString();
        String addons = buildAddons();

        // Explicit Intent ke ResultActivity
        Intent intent = new Intent(this, ResultActivity.class);
        intent.putExtra("name",        name);
        intent.putExtra("email",       email);
        intent.putExtra("phone",       phone);
        intent.putExtra("age",         age);
        intent.putExtra("destination", destination);
        intent.putExtra("flightClass", flightClass);
        intent.putExtra("addons",      addons);
        startActivity(intent);
    }

    private String buildAddons() {
        StringBuilder sb = new StringBuilder();
        if (cbBaggage.isChecked())   sb.append("Bagasi Ekstra, ");
        if (cbMeal.isChecked())      sb.append("Pemilihan Makanan, ");
        if (cbInsurance.isChecked()) sb.append("Asuransi Perjalanan, ");
        if (sb.length() == 0) return "Tidak ada";
        return sb.toString().replaceAll(", $", "");
    }

    private void openHistory() {
        // Explicit Intent ke HistoryActivity
        Intent intent = new Intent(this, HistoryActivity.class);
        startActivity(intent);
    }

    private void openSocialMedia() {
        // Explicit Intent ke SocialMediaActivity
        Intent intent = new Intent(this, SocialMediaActivity.class);
        startActivity(intent);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.main_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        if (id == R.id.menu_social) {
            openSocialMedia();
            return true;
        } else if (id == R.id.menu_website) {
            // Implicit Intent: buka browser
            Intent browserIntent = new Intent(Intent.ACTION_VIEW,
                Uri.parse("https://www.tiket.com"));
            startActivity(browserIntent);
            return true;
        } else if (id == R.id.menu_call) {
            // Implicit Intent: buka telepon
            Intent callIntent = new Intent(Intent.ACTION_DIAL,
                Uri.parse("tel:+62215551234"));
            startActivity(callIntent);
            return true;
        } else if (id == R.id.menu_share) {
            // Implicit Intent: share
            Intent shareIntent = new Intent(Intent.ACTION_SEND);
            shareIntent.setType("text/plain");
            shareIntent.putExtra(Intent.EXTRA_TEXT,
                "Booking perjalanan mudah dengan Travel Booking App!");
            startActivity(Intent.createChooser(shareIntent, "Bagikan via..."));
            return true;
        } else if (id == R.id.menu_email) {
            // Implicit Intent: kirim email
            Intent emailIntent = new Intent(Intent.ACTION_SENDTO,
                Uri.parse("mailto:support@travelbooking.com"));
            emailIntent.putExtra(Intent.EXTRA_SUBJECT, "Bantuan Pemesanan");
            startActivity(emailIntent);
            return true;
        }
        return super.onOptionsItemSelected(item);
    }
}
