package com.example.travelbooking;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

public class HistoryFragment extends Fragment {

    private static final String PREF_NAME = "TravelBookingPref";

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater,
                             @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_history, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        SharedPreferences prefs = requireActivity()
            .getSharedPreferences(PREF_NAME, requireActivity().MODE_PRIVATE);
        int count = prefs.getInt("history_count", 0);

        LinearLayout container = view.findViewById(R.id.ll_history_container);
        TextView tvEmpty = view.findViewById(R.id.tv_empty);

        if (count == 0) {
            tvEmpty.setVisibility(View.VISIBLE);
            container.setVisibility(View.GONE);
            return;
        }

        tvEmpty.setVisibility(View.GONE);
        container.setVisibility(View.VISIBLE);

        for (int i = count - 1; i >= 0; i--) {
            String id    = prefs.getString("history_" + i + "_id",   "-");
            String date  = prefs.getString("history_" + i + "_date", "-");
            String name  = prefs.getString("history_" + i + "_name", "-");
            String dest  = prefs.getString("history_" + i + "_dest", "-");
            String cls   = prefs.getString("history_" + i + "_cls",  "-");
            String total = prefs.getString("history_" + i + "_total","-");

            View cardView = LayoutInflater.from(requireContext())
                .inflate(R.layout.item_history, container, false);

            ((TextView) cardView.findViewById(R.id.tv_item_id)).setText(id);
            ((TextView) cardView.findViewById(R.id.tv_item_date)).setText(date);
            ((TextView) cardView.findViewById(R.id.tv_item_name)).setText(name);
            ((TextView) cardView.findViewById(R.id.tv_item_dest)).setText(dest);
            ((TextView) cardView.findViewById(R.id.tv_item_cls)).setText(cls);
            ((TextView) cardView.findViewById(R.id.tv_item_total)).setText(total);

            container.addView(cardView);
        }
    }
}
