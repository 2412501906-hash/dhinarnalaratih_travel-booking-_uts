package com.example.travelbooking;

import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class ResultActivity extends AppCompatActivity {

    private SharedPreferences sharedPreferences;
    private static final String PREF_NAME = "TravelBookingPref";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_result);

        Toolbar toolbar = findViewById(R.id.toolbar_result);
        setSupportActionBar(toolbar);
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setTitle("Konfirmasi Pemesanan");
        }

        sharedPreferences = getSharedPreferences(PREF_NAME, MODE_PRIVATE);

        // Ambil data dari Intent
        Intent intent = getIntent();
        String name        = intent.getStringExtra("name");
        String email       = intent.getStringExtra("email");
        String phone       = intent.getStringExtra("phone");
        String age         = intent.getStringExtra("age");
        String destination = intent.getStringExtra("destination");
        String flightClass = intent.getStringExtra("flightClass");
        String addons      = intent.getStringExtra("addons");

        // Generate booking ID
        String bookingId = "TRV-" + System.currentTimeMillis() % 100000;
        String bookingDate = new SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.getDefault())
                                .format(new Date());

        // Hitung harga
        int basePrice = calculatePrice(destination, flightClass);
        int addonsPrice = calculateAddons(addons);
        int totalPrice = basePrice + addonsPrice;

        // Tampilkan ke UI
        ((TextView) findViewById(R.id.tv_booking_id)).setText("ID Pemesanan: " + bookingId);
        ((TextView) findViewById(R.id.tv_booking_date)).setText("Tanggal: " + bookingDate);
        ((TextView) findViewById(R.id.tv_name)).setText("Nama: " + name);
        ((TextView) findViewById(R.id.tv_email)).setText("Email: " + email);
        ((TextView) findViewById(R.id.tv_phone)).setText("No. HP: " + phone);
        ((TextView) findViewById(R.id.tv_age)).setText("Usia: " + age + " tahun");
        ((TextView) findViewById(R.id.tv_destination)).setText("Destinasi: " + destination);
        ((TextView) findViewById(R.id.tv_class)).setText("Kelas: " + flightClass);
        ((TextView) findViewById(R.id.tv_addons)).setText("Add-ons: " + addons);
        ((TextView) findViewById(R.id.tv_price)).setText(
            "Harga Tiket: Rp " + String.format(Locale.getDefault(), "%,d", basePrice));
        ((TextView) findViewById(R.id.tv_addons_price)).setText(
            "Harga Add-ons: Rp " + String.format(Locale.getDefault(), "%,d", addonsPrice));
        ((TextView) findViewById(R.id.tv_total)).setText(
            "TOTAL: Rp " + String.format(Locale.getDefault(), "%,d", totalPrice));

        // Simpan riwayat ke SharedPreferences
        saveHistory(bookingId, bookingDate, name, destination, flightClass, totalPrice);

        // Tombol Konfirmasi (share)
        Button btnConfirm = findViewById(R.id.btn_confirm);
        btnConfirm.setOnClickListener(v -> {
            String shareText = buildShareText(bookingId, bookingDate, name,
                    destination, flightClass, addons, totalPrice);
            Intent shareIntent = new Intent(Intent.ACTION_SEND);
            shareIntent.setType("text/plain");
            shareIntent.putExtra(Intent.EXTRA_TEXT, shareText);
            startActivity(Intent.createChooser(shareIntent, "Bagikan tiket via..."));
        });

        // Tombol Kembali ke Home
        Button btnHome = findViewById(R.id.btn_home);
        btnHome.setOnClickListener(v -> {
            Intent homeIntent = new Intent(this, MainActivity.class);
            homeIntent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
            startActivity(homeIntent);
        });

        // Tombol Sosial Media
        Button btnSocialResult = findViewById(R.id.btn_social_result);
        btnSocialResult.setOnClickListener(v -> {
            Intent socialIntent = new Intent(this, SocialMediaActivity.class);
            startActivity(socialIntent);
        });

        // Tombol Lihat di Maps (Implicit Intent)
        Button btnMaps = findViewById(R.id.btn_maps);
        btnMaps.setOnClickListener(v -> {
            String query = Uri.encode(destination);
            Intent mapsIntent = new Intent(Intent.ACTION_VIEW,
                Uri.parse("geo:0,0?q=" + query));
            if (mapsIntent.resolveActivity(getPackageManager()) != null) {
                startActivity(mapsIntent);
            } else {
                // fallback ke browser Google Maps
                Intent browserMaps = new Intent(Intent.ACTION_VIEW,
                    Uri.parse("https://maps.google.com/?q=" + query));
                startActivity(browserMaps);
            }
        });
    }

    private int calculatePrice(String destination, String flightClass) {
        int base = 500000;
        if (destination.contains("Bali"))          base = 800000;
        else if (destination.contains("Raja Ampat")) base = 3000000;
        else if (destination.contains("Labuan"))   base = 2000000;
        else if (destination.contains("Lombok"))   base = 900000;
        else if (destination.contains("Yogya"))    base = 600000;
        else if (destination.contains("Manado"))   base = 1200000;

        if (flightClass.contains("Business")) base *= 2;
        else if (flightClass.contains("First")) base *= 3;
        return base;
    }

    private int calculateAddons(String addons) {
        int price = 0;
        if (addons.contains("Bagasi"))     price += 150000;
        if (addons.contains("Makanan"))    price += 100000;
        if (addons.contains("Asuransi"))   price += 200000;
        return price;
    }

    private void saveHistory(String id, String date, String name,
                             String dest, String cls, int total) {
        SharedPreferences.Editor editor = sharedPreferences.edit();
        // Ambil jumlah history sebelumnya
        int count = sharedPreferences.getInt("history_count", 0);
        editor.putString("history_" + count + "_id",   id);
        editor.putString("history_" + count + "_date", date);
        editor.putString("history_" + count + "_name", name);
        editor.putString("history_" + count + "_dest", dest);
        editor.putString("history_" + count + "_cls",  cls);
        editor.putString("history_" + count + "_total",
            "Rp " + String.format(Locale.getDefault(), "%,d", total));
        editor.putInt("history_count", count + 1);
        editor.apply();
    }

    private String buildShareText(String id, String date, String name,
                                  String dest, String cls, String addons, int total) {
        return "🛫 KONFIRMASI TIKET PERJALANAN\n" +
               "================================\n" +
               "ID: " + id + "\n" +
               "Tanggal: " + date + "\n" +
               "Nama: " + name + "\n" +
               "Tujuan: " + dest + "\n" +
               "Kelas: " + cls + "\n" +
               "Add-ons: " + addons + "\n" +
               "Total: Rp " + String.format(Locale.getDefault(), "%,d", total) + "\n" +
               "================================\n" +
               "Terima kasih telah memesan!";
    }

    @Override
    public boolean onSupportNavigateUp() {
        onBackPressed();
        return true;
    }
}
