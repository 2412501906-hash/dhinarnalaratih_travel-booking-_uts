package com.example.travelbooking;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

public class SocialMediaActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_social_media);

        Toolbar toolbar = findViewById(R.id.toolbar_social);
        setSupportActionBar(toolbar);
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setTitle("Ikuti Kami");
        }

        setupButtons();
    }

    private void setupButtons() {

        // ── GOOGLE ──────────────────────────────────────────
        findViewById(R.id.btn_google_search).setOnClickListener(v ->
            openUrl("https://www.google.com/search?q=wisata+indonesia"));

        findViewById(R.id.btn_google_maps).setOnClickListener(v ->
            openUrl("https://maps.google.com/?q=destinasi+wisata+indonesia"));

        findViewById(R.id.btn_google_review).setOnClickListener(v ->
            openUrl("https://search.google.com/local/reviews"));

        findViewById(R.id.btn_youtube).setOnClickListener(v ->
            openUrl("https://www.youtube.com/@TravelIndonesia"));

        // ── INSTAGRAM ───────────────────────────────────────
        findViewById(R.id.btn_instagram).setOnClickListener(v -> {
            // Coba buka app Instagram dulu, fallback ke browser
            try {
                Intent intent = new Intent(Intent.ACTION_VIEW,
                    Uri.parse("instagram://user?username=explorenusantara"));
                intent.setPackage("com.instagram.android");
                startActivity(intent);
            } catch (Exception e) {
                openUrl("https://www.instagram.com/explorenusantara");
            }
        });

        // ── FACEBOOK ────────────────────────────────────────
        findViewById(R.id.btn_facebook).setOnClickListener(v -> {
            try {
                Intent intent = new Intent(Intent.ACTION_VIEW,
                    Uri.parse("fb://page/TravelBookingApp"));
                intent.setPackage("com.facebook.katana");
                startActivity(intent);
            } catch (Exception e) {
                openUrl("https://www.facebook.com/TravelBookingApp");
            }
        });

        // ── TWITTER / X ─────────────────────────────────────
        findViewById(R.id.btn_twitter).setOnClickListener(v -> {
            try {
                Intent intent = new Intent(Intent.ACTION_VIEW,
                    Uri.parse("twitter://user?screen_name=TravelBookingID"));
                intent.setPackage("com.twitter.android");
                startActivity(intent);
            } catch (Exception e) {
                openUrl("https://twitter.com/TravelBookingID");
            }
        });

        // ── TIKTOK ──────────────────────────────────────────
        findViewById(R.id.btn_tiktok).setOnClickListener(v -> {
            try {
                Intent intent = new Intent(Intent.ACTION_VIEW,
                    Uri.parse("snssdk1233://user/profile/TravelBookingApp"));
                intent.setPackage("com.zhiliaoapp.musically");
                startActivity(intent);
            } catch (Exception e) {
                openUrl("https://www.tiktok.com/@travelbookingapp");
            }
        });

        // ── WHATSAPP ─────────────────────────────────────────
        findViewById(R.id.btn_whatsapp).setOnClickListener(v -> {
            String phone   = "6281234567890"; // ganti dengan nomor WA bisnis
            String message = Uri.encode("Halo, saya ingin bertanya tentang pemesanan tiket.");
            try {
                Intent intent = new Intent(Intent.ACTION_VIEW,
                    Uri.parse("https://api.whatsapp.com/send?phone=" + phone + "&text=" + message));
                intent.setPackage("com.whatsapp");
                startActivity(intent);
            } catch (Exception e) {
                openUrl("https://api.whatsapp.com/send?phone=" + phone + "&text=" + message);
            }
        });

        // ── TELEGRAM ─────────────────────────────────────────
        findViewById(R.id.btn_telegram).setOnClickListener(v -> {
            try {
                Intent intent = new Intent(Intent.ACTION_VIEW,
                    Uri.parse("tg://resolve?domain=TravelBookingApp"));
                intent.setPackage("org.telegram.messenger");
                startActivity(intent);
            } catch (Exception e) {
                openUrl("https://t.me/TravelBookingApp");
            }
        });

        // ── SHARE ALL ────────────────────────────────────────
        findViewById(R.id.btn_share_all).setOnClickListener(v -> {
            Intent shareIntent = new Intent(Intent.ACTION_SEND);
            shareIntent.setType("text/plain");
            shareIntent.putExtra(Intent.EXTRA_TEXT,
                "✈ Travel Booking App — Pesan tiket wisata mudah!\n\n" +
                "📸 Instagram : instagram.com/explorenusantara\n" +
                "📘 Facebook  : facebook.com/TravelBookingApp\n" +
                "🐦 Twitter   : twitter.com/TravelBookingID\n" +
                "🎵 TikTok    : tiktok.com/@travelbookingapp\n" +
                "💬 WhatsApp  : wa.me/6281234567890\n" +
                "📱 Telegram  : t.me/TravelBookingApp\n" +
                "▶ YouTube   : youtube.com/@TravelIndonesia");
            startActivity(Intent.createChooser(shareIntent, "Bagikan ke..."));
        });
    }

    private void openUrl(String url) {
        Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
        if (intent.resolveActivity(getPackageManager()) != null) {
            startActivity(intent);
        } else {
            Toast.makeText(this, "Tidak ada browser yang tersedia", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    public boolean onSupportNavigateUp() {
        onBackPressed();
        return true;
    }
}
