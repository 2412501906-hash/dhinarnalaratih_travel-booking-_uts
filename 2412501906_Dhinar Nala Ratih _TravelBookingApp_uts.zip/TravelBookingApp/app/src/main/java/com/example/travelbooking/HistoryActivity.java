package com.example.travelbooking;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.Button;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.fragment.app.FragmentTransaction;

public class HistoryActivity extends AppCompatActivity {

    private static final String PREF_NAME = "TravelBookingPref";
    private SharedPreferences sharedPreferences;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_history);

        Toolbar toolbar = findViewById(R.id.toolbar_history);
        setSupportActionBar(toolbar);
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setTitle("Riwayat Pemesanan");
        }

        sharedPreferences = getSharedPreferences(PREF_NAME, MODE_PRIVATE);

        // Load HistoryFragment
        if (savedInstanceState == null) {
            HistoryFragment fragment = new HistoryFragment();
            FragmentTransaction ft = getSupportFragmentManager().beginTransaction();
            ft.replace(R.id.fragment_container, fragment);
            ft.commit();
        }

        // Tombol hapus semua riwayat
        Button btnClear = findViewById(R.id.btn_clear_history);
        btnClear.setOnClickListener(v -> {
            SharedPreferences.Editor editor = sharedPreferences.edit();
            int count = sharedPreferences.getInt("history_count", 0);
            for (int i = 0; i < count; i++) {
                editor.remove("history_" + i + "_id");
                editor.remove("history_" + i + "_date");
                editor.remove("history_" + i + "_name");
                editor.remove("history_" + i + "_dest");
                editor.remove("history_" + i + "_cls");
                editor.remove("history_" + i + "_total");
            }
            editor.putInt("history_count", 0);
            editor.apply();
            Toast.makeText(this, "Riwayat berhasil dihapus", Toast.LENGTH_SHORT).show();
            // Reload fragment
            HistoryFragment fragment = new HistoryFragment();
            getSupportFragmentManager().beginTransaction()
                .replace(R.id.fragment_container, fragment)
                .commit();
        });
    }

    @Override
    public boolean onSupportNavigateUp() {
        onBackPressed();
        return true;
    }
}
