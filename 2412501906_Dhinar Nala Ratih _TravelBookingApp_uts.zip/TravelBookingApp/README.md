# Travel Booking App - UTS Mobile Programming

## Informasi Mahasiswa
- **Nama**: [Nama Mahasiswa]
- **NIM**: [NIM Mahasiswa]
- **Mata Kuliah**: Mobile Programming (Kelompok AL)
- **Universitas**: Budi Luhur
- **Semester**: Genap 2025/2026

---

## Deskripsi Aplikasi

**Travel Booking App** adalah aplikasi Android untuk pemesanan tiket perjalanan wisata domestik. Pengguna dapat mengisi data diri, memilih destinasi dan kelas penerbangan, menambahkan layanan ekstra, lalu mendapatkan konfirmasi pemesanan lengkap dengan detail harga.

---

## Fitur Aplikasi

### Fitur Wajib ✅
| No | Ketentuan | Implementasi |
|----|-----------|--------------|
| 1 | Minimal 2 Activity | `MainActivity` (form input) + `ResultActivity` (konfirmasi) + `HistoryActivity` |
| 2 | Explicit Intent | Perpindahan antar Activity (Main→Result, Main→History) |
| 2 | Implicit Intent | Buka browser, telepon CS, share tiket, email support, buka Google Maps |
| 3 | Form Validation | Nama/email/HP/usia tidak boleh kosong, email harus mengandung `@`, HP harus angka, usia harus angka 1-120 |
| 4 | Widget UI | `EditText`, `Spinner`, `RadioButton`/`RadioGroup`, `CheckBox`, `ImageView` |
| 5 | SharedPreferences | Menyimpan data terakhir (nama, email, HP) dan riwayat pemesanan |
| 6 | Fragment | `HistoryFragment` menampilkan daftar riwayat pemesanan |

### Fitur Bonus ✨
- **CardView** — tampilan kartu modern
- **Toolbar** dengan overflow menu (implicit intent: browser, call, share, email)
- **Kalkulasi harga otomatis** berdasarkan destinasi + kelas + add-ons
- **Share tiket** via intent chooser

---

## Struktur Project

```
app/src/main/
├── java/com/example/travelbooking/
│   ├── MainActivity.java          # Form input utama
│   ├── ResultActivity.java        # Tampilan konfirmasi & harga
│   ├── HistoryActivity.java       # Activity riwayat (host Fragment)
│   └── HistoryFragment.java       # Fragment daftar riwayat
├── res/
│   ├── layout/
│   │   ├── activity_main.xml
│   │   ├── activity_result.xml
│   │   ├── activity_history.xml
│   │   ├── fragment_history.xml
│   │   └── item_history.xml
│   ├── menu/main_menu.xml
│   ├── drawable/
│   │   ├── bg_edittext.xml
│   │   ├── bg_spinner.xml
│   │   └── ic_travel_banner.xml
│   └── values/
│       ├── strings.xml
│       └── themes.xml
└── AndroidManifest.xml
```

---

## Cara Menjalankan

1. Clone repository ini
2. Buka dengan **Android Studio**
3. Pastikan SDK 34 sudah terinstall (`compileSdk 34`, `minSdk 24`)
4. Klik **Run** atau build APK via `Build > Build Bundle(s)/APK(s) > Build APK(s)`
5. Install APK di perangkat fisik

---

## Screenshot

> *(Tambahkan screenshot aplikasi di sini)*

---

## Alur Program

```
MainActivity (Form Input)
    ↓ [Explicit Intent + data Bundle]
ResultActivity (Konfirmasi & Harga)
    ↓ [Implicit Intent]
    ├── Share via WhatsApp/dll
    └── Google Maps (lokasi destinasi)

MainActivity
    ↓ [Explicit Intent]
HistoryActivity → HistoryFragment (daftar riwayat dari SharedPreferences)

Toolbar Menu → Implicit Intent:
    ├── Browser (tiket.com)
    ├── Dial (CS phone)
    ├── Share (teks promosi)
    └── Email (support)
```
